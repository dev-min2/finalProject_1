require('dotenv').config({ path : './mysql.env' });
const readXlsxFile = require('read-excel-file/node');
const notifier = require('node-notifier');
const fs = require('fs');
const path = require('path');

let { pool,query } = require('./dbPool');

// 우리꺼
let object = {
    product_no : '0',
    pet_type : 'd1', // 0 or 1
    product_name : '',
    product_price : 0,
    product_detail_desc : '',
    product_image : '',
    product_registdate : '',
    product_stock : 45,
    category_no : 0,
    product_desc : '',
    product_public_state : 'i1'
};

let old = {
    product_no : '0',
    pet_type : 'd1', // 0 or 1
    category_no : 0,
    product_name : '',
    product_price : 0,
    product_desc : '',
    product_image : '',
    product_regist_date : '',
    product_stock : 0
}

let userObj = {
    user_no : '987654321',
    user_id : 'test123',
    user_pw : '3dc3a697552996c97f5028bcfb51de78c6dcb9c2b8fa6881bd69a4531d977b91',
    user_name : '테스트',
    user_birth : '1997-08-02',
    user_email : 'c11286@naver.com',
    user_phone : '010-5247-6023',
    user_addr : '대구 동구 팔공로 1 ㅇㅇ',
    user_permission : 'F2',
    company_name : '예담직업전문학교',
    business_number : '504-86-00471',
    ceo_name : '서강중'
};

async function ff(insertQuery,data) {
    try {
        await query(insertQuery,data);
    }
    catch(e) {
        console.log(e);
    }
    return 1;
}
async function insertProduct() {
    await ff(`INSERT INTO user SET ?`, userObj);

    const csv = fs.readFileSync('./product2.csv',"utf-8");
    const rows = csv.split("\r\n");
    let insertQuerys = [];
    for(let i = 1; i < rows.length; ++i) {
        rows[i] = rows[i].substr(0,rows[i].length - 8);
        let dataArray = rows[i].split(',');

        const productObj = {
            product_no : dataArray[0],
            pet_type : dataArray[1] == '0' ? 'd1' : 'd2',
            category_no : dataArray[2],
            product_name : dataArray[3],
            product_price : dataArray[4],
            product_desc : dataArray[5],
            product_image : dataArray[6],
            product_registdate : dataArray[7],
            product_stock : dataArray[8],
            product_detail_desc : "<p>상품테스트</p>",
            user_no : '987654321',
            product_public_state : 'i1'
        }

        await ff(`INSERT INTO product SET ?`, productObj);
    }

    console.log('작업완료. 창닫으셈');
}


insertProduct();